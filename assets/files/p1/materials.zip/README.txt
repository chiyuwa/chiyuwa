Materials for Project 1

Place your papers, code snapshots, or datasets here.
